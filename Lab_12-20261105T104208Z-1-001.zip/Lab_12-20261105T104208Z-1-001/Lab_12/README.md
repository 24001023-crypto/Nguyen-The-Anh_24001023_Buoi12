# Lab 12 - WinForms QLSinhVien (10 bài)

Solution WinForms 3 lớp (GUI -> BUS -> DAL) cho học phần **Lập trình .NET (IT3212)**,
sử dụng CSDL `QLSinhVien` khởi tạo bởi file `a.sql` (Lab 08).

## Cấu trúc

```
Lab_12/
├── Lab_12.sln
├── Database/
│   └── Lab12_DB.sql          # Bổ sung bảng LichSuChuyenKhoa + cột SinhVien.RowVersion
└── Lab_12/
    ├── Lab_12.csproj         # .NET 8 WinForms
    ├── Program.cs
    ├── Data/
    │   ├── DbConnectionFactory.cs   # Chuỗi kết nối (sv_app_user / Eaut@2026!)
    │   └── Db.cs                    # Helper Query/Exec/Scalar (có overload nhận Transaction)
    ├── DTO/
    │   └── DTOs.cs                  # KhoaDTO, SinhVienDTO, HocPhanDTO, DangKyDTO
    ├── DAL/
    │   ├── KhoaDAL.cs, SinhVienDAL.cs, HocPhanDAL.cs
    │   ├── DangKyDAL.cs             # InsertEnrollment nhận (conn, tx) từ ngoài - Bài 5
    │   └── LichSuChuyenKhoaDAL.cs
    ├── BUS/
    │   ├── KhoaBUS.cs               # Bài 6 (chuyển khoa), Bài 7 (xóa khoa an toàn)
    │   ├── SinhVienBUS.cs           # Bài 3, 4, 5, 8, 9
    │   └── DangKyBUS.cs, HocPhanBUS
    └── Forms/
        ├── MainForm.cs              # Menu mở từng bài
        └── Bai1Form.cs ... Bai10Form.cs
```

## Các bước chạy

1. Chạy `a.sql` (Lab 08) trên SQL Server để tạo CSDL `QLSinhVien` + tài khoản `sv_app_user`.
2. Chạy `Database/Lab12_DB.sql` để tạo bảng `LichSuChuyenKhoa` và cột `SinhVien.RowVersion`.
3. Mở `Lab_12.sln` bằng **Visual Studio 2022** (Windows), bấm `F5`.
4. Nếu SQL Server không phải `localhost`, sửa chuỗi kết nối trong
   `Lab_12/Data/DbConnectionFactory.cs`.

## 10 bài

| Bài | Form | Nội dung |
|-----|------|----------|
| 1 | Bai1Form | Master-detail Khoa - SinhVien (`SelectionChanged` lọc lưới dưới) |
| 2 | Bai2Form | Master-detail SinhVien - Đăng ký (JOIN tên học phần) + thêm đăng ký |
| 3 | Bai3Form | Transaction thêm sinh viên + đăng ký ban đầu (Commit/Rollback) |
| 4 | Bai4Form | Mô phỏng lỗi (thêm mã HP999 không tồn tại) + kiểm chứng Rollback |
| 5 | Bai5Form | DAL nhận `SqlConnection`/`SqlTransaction` từ ngoài; BUS điều phối |
| 6 | Bai6Form | Transaction chuyển khoa + ghi `LichSuChuyenKhoa` |
| 7 | Bai7Form | Xóa khoa an toàn trong transaction (2 chính sách: DELETE_ALL / BLOCK) |
| 8 | Bai8Form | Cập nhật điểm hàng loạt; một điểm ngoài [0,10] -> rollback toàn bộ |
| 9 | Bai9Form | Xung đột cập nhật: `UPDATE ... WHERE RowVersion = @RowVersion` |
| 10 | Bai10Form | CRUD Khoa/SinhVien/HocPhan/DangKy + tìm kiếm + master-detail |
