-- =======================================================================
-- TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á - KHOA CNTT
-- HỌC PHẦN: LẬP TRÌNH .NET (IT3212)
-- LAB 12: TRANSACTION & MASTER-DETAIL
--
-- Tệp: Lab12_DB.sql
-- Mô tả: Bổ sung cho CSDL QLSinhVien (đã tạo bởi Lab08_QLSinhVien.sql / a.sql):
--   + Bảng LichSuChuyenKhoa (dùng cho Bài 6, 7)
--   + Cột RowVersion trên SinhVien (dùng cho Bài 9)
-- Chạy a.sql TRƯỚC, rồi chạy tệp này SAU.
-- =======================================================================

USE QLSinhVien;
GO

-- =======================================================================
-- 1. BẢNG LichSuChuyenKhoa (Bài 6)
-- =======================================================================
IF OBJECT_ID(N'dbo.LichSuChuyenKhoa', N'U') IS NULL
BEGIN
    PRINT N'-- Tạo bảng LichSuChuyenKhoa...';
    CREATE TABLE LichSuChuyenKhoa
    (
        Id        INT IDENTITY(1,1) PRIMARY KEY,
        MaSV      VARCHAR(15)   NOT NULL,
        MaKhoaCu  VARCHAR(10)   NOT NULL,
        MaKhoaMoi VARCHAR(10)   NOT NULL,
        NgayChuyen DATETIME     NOT NULL CONSTRAINT DF_LSCK_Ngay DEFAULT GETDATE(),
        GhiChu    NVARCHAR(200) NULL,
        CONSTRAINT FK_LSCK_SinhVien FOREIGN KEY (MaSV) REFERENCES SinhVien(MaSV) ON DELETE CASCADE,
        CONSTRAINT FK_LSCK_KhoaCu   FOREIGN KEY (MaKhoaCu) REFERENCES Khoa(MaKhoa),
        CONSTRAINT FK_LSCK_KhoaMoi  FOREIGN KEY (MaKhoaMoi) REFERENCES Khoa(MaKhoa)
    );
END
ELSE
    PRINT N'-- Bảng LichSuChuyenKhoa đã tồn tại.';
GO

-- =======================================================================
-- 2. CỘT RowVersion TRÊN SinhVien (Bài 9 - kiểm soát xung đột cập nhật)
-- =======================================================================
IF COL_LENGTH(N'dbo.SinhVien', N'RowVersion') IS NULL
BEGIN
    PRINT N'-- Thêm cột RowVersion vào SinhVien...';
    ALTER TABLE dbo.SinhVien ADD RowVersion ROWVERSION;
END
ELSE
    PRINT N'-- Cột SinhVien.RowVersion đã tồn tại.';
GO

-- =======================================================================
-- 3. CẤP QUYỀN cho tài khoản ứng dụng sv_app_user (tạo trong a.sql)
-- =======================================================================
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.LichSuChuyenKhoa TO sv_app_user;
GO

PRINT N'=======================================================================';
PRINT N'-- HOÀN TẤT BỔ SUNG CSDL CHO LAB 12!';
PRINT N'=======================================================================';
GO
