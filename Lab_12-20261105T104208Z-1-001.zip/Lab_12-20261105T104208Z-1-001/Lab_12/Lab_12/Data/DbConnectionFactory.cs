using Microsoft.Data.SqlClient;

namespace Lab_12.DAL
{
    /// <summary>
    /// Factory tạo kết nối tới CSDL QLSinhVien (khớp cấu hình trong a.sql).
    /// </summary>
    public static class DbConnectionFactory
    {
        // Windows Authentication (đăng nhập bằng tài khoản Windows hiện tại)
        public const string ConnectionString =
            @"Server=ADUUUUU\SQLEXPRESS;Database=QLSinhVien;Trusted_Connection=True;TrustServerCertificate=True;";

        public static SqlConnection Create()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
