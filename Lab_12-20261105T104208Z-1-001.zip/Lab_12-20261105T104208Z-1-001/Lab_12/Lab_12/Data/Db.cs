using Microsoft.Data.SqlClient;
using System.Data;

namespace Lab_12.DAL
{
    /// <summary>
    /// Helper thực thi SQL dùng chung. Mọi phương thức đều có bản overload
    /// nhận SqlConnection + SqlTransaction để tham gia giao dịch từ bên ngoài (Bài 5).
    /// </summary>
    public static class Db
    {
        // ---------------- SELECT ----------------
        public static DataTable Query(string sql, params SqlParameter[] ps)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            return Query(conn, null, sql, ps);
        }

        public static DataTable Query(SqlConnection conn, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            if (tx == null && conn.State != ConnectionState.Open) conn.Open();
            using var cmd = new SqlCommand(sql, conn, tx);
            if (ps != null) cmd.Parameters.AddRange(ps);
            using var da = new SqlDataAdapter(cmd);
            var dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        // ---------------- INSERT/UPDATE/DELETE ----------------
        public static int Exec(string sql, params SqlParameter[] ps)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            return Exec(conn, null, sql, ps);
        }

        public static int Exec(SqlConnection conn, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            if (tx == null && conn.State != ConnectionState.Open) conn.Open();
            using var cmd = new SqlCommand(sql, conn, tx);
            if (ps != null) cmd.Parameters.AddRange(ps);
            return cmd.ExecuteNonQuery();
        }

        // ---------------- SELECT một giá trị đơn ----------------
        public static object Scalar(string sql, params SqlParameter[] ps)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            return Scalar(conn, null, sql, ps);
        }

        public static object Scalar(SqlConnection conn, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            if (tx == null && conn.State != ConnectionState.Open) conn.Open();
            using var cmd = new SqlCommand(sql, conn, tx);
            if (ps != null) cmd.Parameters.AddRange(ps);
            return cmd.ExecuteScalar();
        }
    }
}
