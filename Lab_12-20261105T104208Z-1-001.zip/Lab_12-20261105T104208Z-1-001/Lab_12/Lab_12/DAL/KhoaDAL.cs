using Microsoft.Data.SqlClient;
using System.Data;
using Lab_12.DTO;

namespace Lab_12.DAL
{
    public class KhoaDAL
    {
        public DataTable GetAll()
        {
            return Db.Query("SELECT MaKhoa, TenKhoa FROM Khoa ORDER BY MaKhoa");
        }

        public bool Exists(string maKhoa, SqlConnection conn, SqlTransaction tx)
        {
            return Convert.ToInt32(Db.Scalar(conn, tx,
                "SELECT COUNT(*) FROM Khoa WHERE MaKhoa = @MaKhoa",
                new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa })) > 0;
        }

        public int Delete(string maKhoa, SqlConnection conn, SqlTransaction tx)
        {
            return Db.Exec(conn, tx, "DELETE FROM Khoa WHERE MaKhoa = @MaKhoa",
                new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa });
        }
    }
}
