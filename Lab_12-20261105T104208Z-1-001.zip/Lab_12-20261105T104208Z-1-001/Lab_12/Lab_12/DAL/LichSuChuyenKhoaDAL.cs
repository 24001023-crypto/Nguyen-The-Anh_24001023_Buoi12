using Microsoft.Data.SqlClient;
using System.Data;

namespace Lab_12.DAL
{
    /// <summary>Bảng LichSuChuyenKhoa được bổ sung bởi Database/Lab12_DB.sql (Bài 6).</summary>
    public class LichSuChuyenKhoaDAL
    {
        public int Insert(string maSV, string maKhoaCu, string maKhoaMoi, string ghiChu,
                          SqlConnection conn, SqlTransaction tx)
        {
            const string sql = @"INSERT INTO LichSuChuyenKhoa(MaSV, MaKhoaCu, MaKhoaMoi, NgayChuyen, GhiChu)
                                 VALUES(@MaSV, @MaKhoaCu, @MaKhoaMoi, GETDATE(), @GhiChu)";
            return Db.Exec(conn, tx, sql,
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV },
                new SqlParameter("@MaKhoaCu", SqlDbType.VarChar, 10) { Value = maKhoaCu },
                new SqlParameter("@MaKhoaMoi", SqlDbType.VarChar, 10) { Value = maKhoaMoi },
                new SqlParameter("@GhiChu", SqlDbType.NVarChar, 200) { Value = (object)ghiChu ?? DBNull.Value });
        }

        public int DeleteByDepartment(string maKhoa, SqlConnection conn, SqlTransaction tx)
        {
            return Db.Exec(conn, tx,
                "DELETE FROM LichSuChuyenKhoa WHERE MaKhoaCu = @MaKhoa OR MaKhoaMoi = @MaKhoa",
                new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa });
        }
    }
}
