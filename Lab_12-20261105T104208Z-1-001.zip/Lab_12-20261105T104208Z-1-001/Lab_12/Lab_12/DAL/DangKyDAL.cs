using Microsoft.Data.SqlClient;
using System.Data;
using Lab_12.DTO;

namespace Lab_12.DAL
{
    public class DangKyDAL
    {
        /// <summary>Bài 2: JOIN để hiển thị tên học phần theo sinh viên.</summary>
        public DataTable GetByStudent(string maSV)
        {
            const string sql = @"SELECT dk.MaSV, dk.MaHP, hp.TenHP, hp.SoTinChi, dk.HocKy, dk.Diem
                                 FROM DangKy dk
                                 JOIN HocPhan hp ON dk.MaHP = hp.MaHP
                                 WHERE dk.MaSV = @MaSV
                                 ORDER BY dk.HocKy, hp.TenHP";
            return Db.Query(sql,
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV });
        }

        public DataTable GetAllWithNames(string search = null)
        {
            const string sql = @"SELECT dk.MaSV, sv.HoTen, dk.MaHP, hp.TenHP, dk.HocKy, dk.NgayDangKy, dk.Diem
                                 FROM DangKy dk
                                 JOIN HocPhan hp ON dk.MaHP = hp.MaHP
                                 JOIN SinhVien sv ON dk.MaSV = sv.MaSV
                                 WHERE (@Search IS NULL OR dk.MaSV LIKE '%' + @Search + '%'
                                        OR sv.HoTen LIKE N'%' + @Search + '%'
                                        OR dk.MaHP LIKE '%' + @Search + '%')
                                 ORDER BY dk.MaSV, dk.MaHP";
            return Db.Query(sql,
                new SqlParameter("@Search", SqlDbType.NVarChar, 100) { Value = (object)search ?? DBNull.Value });
        }

        /// <summary>
        /// Bài 5: cho phép nhận SqlConnection + SqlTransaction từ bên ngoài.
        /// Nếu conn == null thì tự mở kết nối riêng (dùng độc lập).
        /// </summary>
        public void InsertEnrollment(DangKyDTO dto, SqlConnection conn, SqlTransaction tx)
        {
            const string sql = @"INSERT INTO DangKy(MaSV, MaHP, HocKy, Diem)
                                 VALUES(@MaSV, @MaHP, @HocKy, @Diem)";
            bool ownConnection = (conn == null);
            if (ownConnection)
            {
                conn = DbConnectionFactory.Create();
                conn.Open();
            }
            try
            {
                using var cmd = new SqlCommand(sql, conn, tx);
                cmd.Parameters.Add("@MaSV", SqlDbType.VarChar, 15).Value = dto.MaSV;
                cmd.Parameters.Add("@MaHP", SqlDbType.VarChar, 10).Value = dto.MaHP;
                cmd.Parameters.Add("@HocKy", SqlDbType.Int).Value = dto.HocKy;
                cmd.Parameters.Add("@Diem", SqlDbType.Decimal).Value =
                    dto.Diem.HasValue ? (object)dto.Diem.Value : DBNull.Value;
                cmd.ExecuteNonQuery();
            }
            finally
            {
                if (ownConnection) conn.Dispose();
            }
        }

        /// <summary>Bài 8: cập nhật điểm một đăng ký (dùng trong transaction cập nhật hàng loạt).</summary>
        public int UpdateDiem(string maSV, string maHP, decimal diem, SqlConnection conn, SqlTransaction tx)
        {
            const string sql = @"UPDATE DangKy SET Diem = @Diem
                                 WHERE MaSV = @MaSV AND MaHP = @MaHP";
            return Db.Exec(conn, tx, sql,
                new SqlParameter("@Diem", SqlDbType.Decimal) { Value = diem },
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV },
                new SqlParameter("@MaHP", SqlDbType.VarChar, 10) { Value = maHP });
        }

        public int DeleteByStudent(string maSV, SqlConnection conn, SqlTransaction tx)
        {
            return Db.Exec(conn, tx, "DELETE FROM DangKy WHERE MaSV = @MaSV",
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV });
        }

        public int CountByDepartment(string maKhoa, SqlConnection conn, SqlTransaction tx)
        {
            const string sql = @"SELECT COUNT(*) FROM DangKy dk
                                 JOIN SinhVien sv ON dk.MaSV = sv.MaSV
                                 WHERE sv.MaKhoa = @MaKhoa";
            return Convert.ToInt32(Db.Scalar(conn, tx, sql,
                new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa }));
        }
    }
}
