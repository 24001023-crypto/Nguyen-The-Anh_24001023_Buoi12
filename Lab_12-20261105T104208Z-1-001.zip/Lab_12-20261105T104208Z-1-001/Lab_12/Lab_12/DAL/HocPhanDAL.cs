using Microsoft.Data.SqlClient;
using System.Data;

namespace Lab_12.DAL
{
    public class HocPhanDAL
    {
        public DataTable GetAll()
        {
            return Db.Query("SELECT MaHP, TenHP, SoTinChi FROM HocPhan ORDER BY MaHP");
        }

        public bool Exists(string maHP, SqlConnection conn, SqlTransaction tx)
        {
            return Convert.ToInt32(Db.Scalar(conn, tx,
                "SELECT COUNT(*) FROM HocPhan WHERE MaHP = @MaHP",
                new SqlParameter("@MaHP", SqlDbType.VarChar, 10) { Value = maHP })) > 0;
        }
    }
}
