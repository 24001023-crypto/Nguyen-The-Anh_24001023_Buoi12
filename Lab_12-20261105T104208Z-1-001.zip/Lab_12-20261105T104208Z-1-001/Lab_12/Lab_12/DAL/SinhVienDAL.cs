using Microsoft.Data.SqlClient;
using System.Data;
using Lab_12.DTO;

namespace Lab_12.DAL
{
    public class SinhVienDAL
    {
        /// <summary>Bài 1: tải danh sách sinh viên theo khoa (truy vấn tham số).</summary>
        public DataTable GetByDepartment(string maKhoa)
        {
            const string sql = @"SELECT MaSV, HoTen, NgaySinh, GioiTinh, DiemTB, Email
                                 FROM SinhVien
                                 WHERE MaKhoa = @MaKhoa
                                 ORDER BY MaSV";
            return Db.Query(sql,
                new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa });
        }

        public DataTable GetAll(string search = null)
        {
            const string sql = @"SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh,
                                        sv.DiemTB, sv.Email, sv.MaKhoa, k.TenKhoa
                                 FROM SinhVien sv
                                 JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
                                 WHERE (@Search IS NULL OR sv.HoTen LIKE N'%' + @Search + '%' OR sv.MaSV LIKE '%' + @Search + '%')
                                 ORDER BY sv.MaSV";
            return Db.Query(sql,
                new SqlParameter("@Search", SqlDbType.NVarChar, 100) { Value = (object)search ?? DBNull.Value });
        }

        public DataTable GetWithRowVersion(string maSV)
        {
            const string sql = @"SELECT MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email, RowVersion
                                 FROM SinhVien WHERE MaSV = @MaSV";
            return Db.Query(sql,
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV });
        }

        public bool Exists(string maSV, SqlConnection conn, SqlTransaction tx)
        {
            return Convert.ToInt32(Db.Scalar(conn, tx,
                "SELECT COUNT(*) FROM SinhVien WHERE MaSV = @MaSV",
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV })) > 0;
        }

        public int CountAll(SqlConnection conn = null, SqlTransaction tx = null)
        {
            string sql = "SELECT COUNT(*) FROM SinhVien";
            if (conn == null) return Convert.ToInt32(Db.Scalar(sql));
            return Convert.ToInt32(Db.Scalar(conn, tx, sql));
        }

        public int CountByDepartment(string maKhoa, SqlConnection conn = null, SqlTransaction tx = null)
        {
            const string sql = "SELECT COUNT(*) FROM SinhVien WHERE MaKhoa = @MaKhoa";
            var p = new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa };
            if (conn == null) return Convert.ToInt32(Db.Scalar(sql, p));
            return Convert.ToInt32(Db.Scalar(conn, tx, sql, p));
        }

        /// <summary>Bài 5: DAL nhận Connection + Transaction từ bên ngoài khi tham gia giao dịch.</summary>
        public int Insert(SinhVienDTO dto, SqlConnection conn, SqlTransaction tx)
        {
            const string sql = @"INSERT INTO SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email)
                                 VALUES(@MaSV, @HoTen, @NgaySinh, @GioiTinh, @MaKhoa, @DiemTB, @Email)";
            using var cmd = new SqlCommand(sql, conn, tx);
            cmd.Parameters.Add("@MaSV", SqlDbType.VarChar, 15).Value = dto.MaSV;
            cmd.Parameters.Add("@HoTen", SqlDbType.NVarChar, 100).Value = dto.HoTen;
            cmd.Parameters.Add("@NgaySinh", SqlDbType.Date).Value = dto.NgaySinh;
            cmd.Parameters.Add("@GioiTinh", SqlDbType.Bit).Value = dto.GioiTinh;
            cmd.Parameters.Add("@MaKhoa", SqlDbType.VarChar, 10).Value = dto.MaKhoa;
            cmd.Parameters.Add("@DiemTB", SqlDbType.Decimal).Value = dto.DiemTB;
            cmd.Parameters.Add("@Email", SqlDbType.VarChar, 100).Value =
                string.IsNullOrWhiteSpace(dto.Email) ? (object)DBNull.Value : dto.Email;
            return cmd.ExecuteNonQuery();
        }

        /// <summary>Bài 9: UPDATE có kèm RowVersion để phát hiện xung đột cập nhật.</summary>
        public int UpdateWithRowVersion(SinhVienDTO dto, byte[] rowVersion)
        {
            const string sql = @"UPDATE SinhVien
                                 SET HoTen = @HoTen, DiemTB = @DiemTB
                                 WHERE MaSV = @MaSV AND RowVersion = @RowVersion";
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.Add("@MaSV", SqlDbType.VarChar, 15).Value = dto.MaSV;
            cmd.Parameters.Add("@HoTen", SqlDbType.NVarChar, 100).Value = dto.HoTen;
            cmd.Parameters.Add("@DiemTB", SqlDbType.Decimal).Value = dto.DiemTB;
            cmd.Parameters.Add("@RowVersion", SqlDbType.Timestamp).Value = rowVersion;
            return cmd.ExecuteNonQuery();
        }

        /// <summary>Bài 9: mô phỏng "người khác" đã sửa bản ghi (không kiểm tra RowVersion).</summary>
        public int UpdateIgnoreRowVersion(string maSV, string hoTen, decimal diemTB)
        {
            const string sql = @"UPDATE SinhVien SET HoTen = @HoTen, DiemTB = @DiemTB WHERE MaSV = @MaSV";
            return Db.Exec(sql,
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV },
                new SqlParameter("@HoTen", SqlDbType.NVarChar, 100) { Value = hoTen },
                new SqlParameter("@DiemTB", SqlDbType.Decimal) { Value = diemTB });
        }

        public int UpdateMaKhoa(string maSV, string maKhoaMoi, SqlConnection conn, SqlTransaction tx)
        {
            return Db.Exec(conn, tx,
                "UPDATE SinhVien SET MaKhoa = @MaKhoaMoi WHERE MaSV = @MaSV",
                new SqlParameter("@MaKhoaMoi", SqlDbType.VarChar, 10) { Value = maKhoaMoi },
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV });
        }

        public int Delete(string maSV, SqlConnection conn, SqlTransaction tx)
        {
            return Db.Exec(conn, tx, "DELETE FROM SinhVien WHERE MaSV = @MaSV",
                new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV });
        }
    }
}
