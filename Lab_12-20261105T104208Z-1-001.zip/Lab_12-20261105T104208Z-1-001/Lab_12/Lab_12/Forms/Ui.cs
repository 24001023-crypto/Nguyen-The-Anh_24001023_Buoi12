using System.Data;

namespace Lab_12.Forms
{
    /// <summary>Helper dựng UI nhanh (grid, bảng nhập liệu).</summary>
    internal static class Ui
    {
        public static DataGridView MakeGrid(bool readOnly = true)
        {
            return new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = readOnly,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = !readOnly,
                AutoGenerateColumns = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
        }

        public static TableLayoutPanel MakeInputTable(int rows, int cols = 2)
        {
            var t = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = cols,
                RowCount = rows,
                Padding = new Padding(8)
            };
            for (int i = 0; i < cols; i++)
                t.ColumnStyles.Add(new ColumnStyle(i % 2 == 0 ? SizeType.Absolute : SizeType.Percent, i % 2 == 0 ? 120 : 100));
            return t;
        }

        public static void AddRow(TableLayoutPanel t, string label, Control c)
        {
            int row = t.RowCount;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
            t.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
            c.Dock = DockStyle.Fill;
            t.Controls.Add(c, 1, row);
        }
    }
}
