using Lab_12.BUS;
using Lab_12.DTO;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 2: Master-detail SinhVien - Đăng ký học phần (JOIN hiển thị tên học phần),
    /// cho phép thêm đăng ký mới.
    /// </summary>
    public class Bai2Form : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly DangKyBUS _dkBus = new DangKyBUS();
        private readonly HocPhanBUS _hpBus = new HocPhanBUS();

        private readonly DataGridView dgvSinhVien = Ui.MakeGrid();
        private readonly DataGridView dgvDangKy = Ui.MakeGrid();
        private readonly ComboBox cboMaHP = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly NumericUpDown numHocKy = new() { Minimum = 1, Maximum = 3, Value = 1 };
        private readonly NumericUpDown numDiem = new() { Minimum = 0, Maximum = 10, DecimalPlaces = 2 };
        private readonly CheckBox chkDiem = new() { Text = "Có điểm", Checked = false };
        private readonly Label lblChiTiet = new() { Dock = DockStyle.Top, Height = 30, TextAlign = ContentAlignment.MiddleLeft };
        private readonly Button btnThem = new() { Text = "Thêm đăng ký", Width = 120 };

        public Bai2Form()
        {
            Text = "Bài 2: Master-detail SinhVien - Đăng ký học phần";
            Width = 950; Height = 640; StartPosition = FormStartPosition.CenterScreen;

            dgvSinhVien.Dock = DockStyle.Top;
            dgvSinhVien.Height = 180;

            var panel = new Panel { Dock = DockStyle.Bottom, Height = 90, Padding = new Padding(8) };
            cboMaHP.Width = 220;
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill };
            flow.Controls.Add(new Label { Text = "Học phần:", AutoSize = true, TextAlign = ContentAlignment.MiddleCenter });
            flow.Controls.Add(cboMaHP);
            flow.Controls.Add(new Label { Text = "Học kỳ:", AutoSize = true, TextAlign = ContentAlignment.MiddleCenter });
            flow.Controls.Add(numHocKy);
            flow.Controls.Add(chkDiem);
            flow.Controls.Add(numDiem);
            flow.Controls.Add(btnThem);
            panel.Controls.Add(flow);

            Controls.Add(dgvDangKy);
            Controls.Add(lblChiTiet);
            Controls.Add(dgvSinhVien);
            Controls.Add(panel);

            btnThem.Click += BtnThem_Click;
            Load += Bai2Form_Load;
        }

        private void Bai2Form_Load(object sender, EventArgs e)
        {
            dgvSinhVien.DataSource = _svBus.GetAll();

            cboMaHP.DataSource = _hpBus.GetAll();
            cboMaHP.DisplayMember = "TenHP";
            cboMaHP.ValueMember = "MaHP";

            dgvSinhVien.SelectionChanged += DgvSinhVien_SelectionChanged;
            DgvSinhVien_SelectionChanged(null, null);
        }

        private void DgvSinhVien_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null) return;
            string maSV = Convert.ToString(dgvSinhVien.CurrentRow.Cells["MaSV"].Value);
            dgvDangKy.ReadOnly = true;
            dgvDangKy.DataSource = _dkBus.GetByStudent(maSV);
            lblChiTiet.Text = "Các học phần đã đăng ký của: " + maSV;
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null || cboMaHP.SelectedValue == null) return;
            var dto = new DangKyDTO
            {
                MaSV = Convert.ToString(dgvSinhVien.CurrentRow.Cells["MaSV"].Value),
                MaHP = Convert.ToString(cboMaHP.SelectedValue),
                HocKy = (int)numHocKy.Value,
                Diem = chkDiem.Checked ? numDiem.Value : (decimal?)null
            };
            try
            {
                _dkBus.Add(dto);
                MessageBox.Show("Đã thêm đăng ký!", "Thành công");
                DgvSinhVien_SelectionChanged(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Thêm thất bại (có thể đã đăng ký học phần này rồi).\n" + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
