using Lab_12.BUS;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 1: Giao diện master-detail Khoa - SinhVien.
    /// Chọn khoa ở lưới trên -> lưới dưới chỉ hiện sinh viên thuộc khoa đó.
    /// </summary>
    public class Bai1Form : Form
    {
        private readonly KhoaBUS _khoaBus = new KhoaBUS();
        private readonly SinhVienBUS _sinhVienBus = new SinhVienBUS();

        private readonly DataGridView dgvKhoa = Ui.MakeGrid();
        private readonly DataGridView dgvSinhVien = Ui.MakeGrid();
        private readonly Label lblChiTiet = new()
        {
            Text = "Chọn một khoa ở lưới trên.",
            Dock = DockStyle.Top,
            Height = 30,
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };

        public Bai1Form()
        {
            Text = "Bài 1: Master-detail Khoa - SinhVien";
            Width = 900; Height = 640; StartPosition = FormStartPosition.CenterScreen;

            dgvKhoa.Dock = DockStyle.Top;
            dgvKhoa.Height = 200;

            // Thứ tự thêm quyết định vị trí bám: Fill trước, rồi Top
            Controls.Add(dgvSinhVien);
            Controls.Add(lblChiTiet);
            Controls.Add(dgvKhoa);

            Load += Bai1Form_Load;
        }

        private void Bai1Form_Load(object sender, EventArgs e)
        {
            dgvKhoa.DataSource = _khoaBus.GetAll();
            dgvKhoa.SelectionChanged += DgvKhoa_SelectionChanged;
            DgvKhoa_SelectionChanged(null, null); // chọn sẵn dòng đầu
        }

        private void DgvKhoa_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvKhoa.CurrentRow == null) return;
            string maKhoa = Convert.ToString(dgvKhoa.CurrentRow.Cells["MaKhoa"].Value);
            dgvSinhVien.DataSource = _sinhVienBus.GetByDepartment(maKhoa);
            lblChiTiet.Text = "Sinh viên thuộc khoa: " + maKhoa;
        }
    }
}
