using System.Data;
using Lab_12.BUS;
using Lab_12.DTO;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 3: Thêm sinh viên + danh sách đăng ký ban đầu trong MỘT giao dịch.
    /// </summary>
    public class Bai3Form : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly KhoaBUS _khoaBus = new KhoaBUS();
        private readonly HocPhanBUS _hpBus = new HocPhanBUS();

        private readonly TextBox txtMaSV = new();
        private readonly TextBox txtHoTen = new();
        private readonly DateTimePicker dtpNgaySinh = new() { Format = DateTimePickerFormat.Short, Value = new DateTime(2005, 1, 1) };
        private readonly CheckBox chkNam = new() { Text = "Nam", Checked = true, AutoSize = true };
        private readonly ComboBox cboMaKhoa = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly NumericUpDown numDiemTB = new() { Minimum = 0, Maximum = 10, DecimalPlaces = 2 };
        private readonly TextBox txtEmail = new();
        private readonly CheckedListBox lstHocPhan = new() { CheckOnClick = true };
        private readonly NumericUpDown numHocKy = new() { Minimum = 1, Maximum = 3, Value = 1, Width = 80 };
        private readonly Button btnSave = new() { Text = "Lưu sinh viên và đăng ký", Dock = DockStyle.Fill };

        public Bai3Form()
        {
            Text = "Bài 3: Thêm sinh viên và đăng ký (giao dịch)";
            Width = 720; Height = 660; StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(640, 560);

            // Bố cục gốc: 3 hàng — thông tin SV / học phần / nút Lưu
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(8) };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 250));   // nhóm thông tin sinh viên
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));    // nhóm học phần
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));    // nút lưu

            // ---- Nhóm 1: thông tin sinh viên ----
            var grpSv = new GroupBox { Text = "Thông tin sinh viên", Dock = DockStyle.Fill };
            var table = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 7, Padding = new Padding(4) };
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < 7; i++) table.RowStyles.Add(new RowStyle(SizeType.Percent, 100 / 7f));
            Ui.AddRow(table, "Mã SV:", txtMaSV);
            Ui.AddRow(table, "Họ tên:", txtHoTen);
            Ui.AddRow(table, "Ngày sinh:", dtpNgaySinh);
            Ui.AddRow(table, "Giới tính:", chkNam);
            Ui.AddRow(table, "Khoa:", cboMaKhoa);
            Ui.AddRow(table, "Điểm TB:", numDiemTB);
            Ui.AddRow(table, "Email:", txtEmail);
            grpSv.Controls.Add(table);

            // ---- Nhóm 2: học phần đăng ký ban đầu ----
            var grpHp = new GroupBox { Text = "Học phần đăng ký ban đầu", Dock = DockStyle.Fill };
            var lbl = new Label { Text = "Chọn học phần (tick vào ô), rồi chọn học kỳ:", Dock = DockStyle.Top, Height = 26 };
            var panelHocKy = new Panel { Dock = DockStyle.Bottom, Height = 36 };
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill };
            flow.Controls.Add(new Label { Text = "Học kỳ:", AutoSize = true, TextAlign = ContentAlignment.MiddleCenter });
            flow.Controls.Add(numHocKy);
            panelHocKy.Controls.Add(flow);
            lstHocPhan.Dock = DockStyle.Fill;
            grpHp.Controls.Add(lstHocPhan);
            grpHp.Controls.Add(panelHocKy);
            grpHp.Controls.Add(lbl);

            // ---- Nhóm 3: nút lưu ----
            root.Controls.Add(grpSv, 0, 0);
            root.Controls.Add(grpHp, 0, 1);
            root.Controls.Add(btnSave, 0, 2);

            Controls.Add(root);

            btnSave.Click += BtnSave_Click;
            Load += (s, e) =>
            {
                cboMaKhoa.DataSource = _khoaBus.GetAll();
                cboMaKhoa.DisplayMember = "TenKhoa";
                cboMaKhoa.ValueMember = "MaKhoa";
                lstHocPhan.DataSource = _hpBus.GetAll();
                lstHocPhan.DisplayMember = "TenHP";
            };
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            var sv = new SinhVienDTO
            {
                MaSV = txtMaSV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                NgaySinh = dtpNgaySinh.Value.Date,
                GioiTinh = chkNam.Checked,
                MaKhoa = Convert.ToString(cboMaKhoa.SelectedValue),
                DiemTB = numDiemTB.Value,
                Email = txtEmail.Text.Trim()
            };

            // Gom danh sách đăng ký ban đầu từ các mục được tick
            var dsDangKy = new List<DangKyDTO>();
            foreach (var item in lstHocPhan.CheckedItems)
            {
                var row = ((DataRowView)item).Row;
                dsDangKy.Add(new DangKyDTO
                {
                    MaSV = sv.MaSV,
                    MaHP = Convert.ToString(row["MaHP"]),
                    HocKy = (int)numHocKy.Value,
                    Diem = null
                });
            }

            try
            {
                _svBus.AddStudentWithEnrollments(sv, dsDangKy);
                MessageBox.Show($"Đã lưu sinh viên {sv.MaSV} và {dsDangKy.Count} đăng ký vào CSDL.",
                    "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giao dịch thất bại, toàn bộ dữ liệu đã được hoàn tác.\n" + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
