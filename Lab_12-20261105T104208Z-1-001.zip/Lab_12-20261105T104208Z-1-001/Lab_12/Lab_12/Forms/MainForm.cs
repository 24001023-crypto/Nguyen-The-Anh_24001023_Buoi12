namespace Lab_12.Forms
{
    /// <summary>Menu chính: mở giao diện từng bài 1 -> 10.</summary>
    public class MainForm : Form
    {
        private static readonly (string Ma, string MoTa)[] Bai =
        {
            ("Bài 1",  "Master-detail Khoa - SinhVien"),
            ("Bài 2",  "Master-detail SinhVien - Đăng ký học phần (+ thêm đăng ký)"),
            ("Bài 3",  "Transaction thêm sinh viên và đăng ký"),
            ("Bài 4",  "Mô phỏng lỗi và kiểm chứng Rollback"),
            ("Bài 5",  "Hoàn thiện lớp DAL dùng transaction (nhận Connection/Transaction từ ngoài)"),
            ("Bài 6",  "Chuyển sinh viên sang khoa khác + lịch sử chuyển khoa"),
            ("Bài 7",  "Xóa khoa an toàn (không để dữ liệu mồ côi)"),
            ("Bài 8",  "Cập nhật điểm hàng loạt (điểm ngoài [0,10] -> rollback)"),
            ("Bài 9",  "Kiểm soát xung đột cập nhật (RowVersion)"),
            ("Bài 10", "CRUD hoàn chỉnh Khoa/SinhVien/HocPhan/DangKy + tìm kiếm")
        };

        public MainForm()
        {
            Text = "Lab 12 - QLSinhVien (IT3212 - Lập trình .NET)";
            Width = 640; Height = 480; StartPosition = FormStartPosition.CenterScreen;

            var list = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true
            };
            list.Columns.Add("Bài", 70);
            list.Columns.Add("Chức năng", 520);
            foreach (var b in Bai)
            {
                var item = new ListViewItem(new[] { b.Ma, b.MoTa }) { Tag = b.Ma };
                list.Items.Add(item);
            }
            list.DoubleClick += (s, e) => Open(list.SelectedItems);

            var btnOpen = new Button { Text = "Mở bài đã chọn (hoặc double-click)", Dock = DockStyle.Bottom, Height = 44 };
            btnOpen.Click += (s, e) => Open(list.SelectedItems);

            Controls.Add(list);
            Controls.Add(btnOpen);
        }

        private static void Open(ListView.SelectedListViewItemCollection items)
        {
            if (items.Count == 0) return;
            string key = Convert.ToString(items[0].Tag);
            Form f = key switch
            {
                "Bài 1"  => new Bai1Form(),
                "Bài 2"  => new Bai2Form(),
                "Bài 3"  => new Bai3Form(),
                "Bài 4"  => new Bai4Form(),
                "Bài 5"  => new Bai5Form(),
                "Bài 6"  => new Bai6Form(),
                "Bài 7"  => new Bai7Form(),
                "Bài 8"  => new Bai8Form(),
                "Bài 9"  => new Bai9Form(),
                "Bài 10" => new Bai10Form(),
                _ => null
            };
            if (f != null) f.Show();
        }
    }
}
