using Lab_12.BUS;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 5: Hoàn thiện lớp DAL dùng transaction - các phương thức DAL nhận
    /// SqlConnection + SqlTransaction từ bên ngoài; BUS điều phối nghiệp vụ.
    /// Demo: thêm đăng ký + tính lại DiemTB trong cùng một giao dịch.
    /// </summary>
    public class Bai5Form : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly HocPhanBUS _hpBus = new HocPhanBUS();

        private readonly ComboBox cboMaSV = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly ComboBox cboMaHP = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly NumericUpDown numHocKy = new() { Minimum = 1, Maximum = 3, Value = 1 };
        private readonly NumericUpDown numDiem = new() { Minimum = 0, Maximum = 10, DecimalPlaces = 2 };
        private readonly Button btnThucHien = new() { Text = "Thực hiện (Transaction: thêm đăng ký + cập nhật DiemTB)" };
        private readonly Label lblKetQua = new() { Dock = DockStyle.Bottom, Height = 60, TextAlign = ContentAlignment.MiddleLeft };

        public Bai5Form()
        {
            Text = "Bài 5: DAL dùng transaction (nhận Connection + Transaction từ ngoài)";
            Width = 720; Height = 320; StartPosition = FormStartPosition.CenterScreen;

            var table = Ui.MakeInputTable(4);
            Ui.AddRow(table, "Sinh viên:", cboMaSV);
            Ui.AddRow(table, "Học phần:", cboMaHP);
            Ui.AddRow(table, "Học kỳ:", numHocKy);
            Ui.AddRow(table, "Điểm:", numDiem);

            Controls.Add(btnThucHien);
            Controls.Add(table);
            Controls.Add(lblKetQua);
            btnThucHien.Dock = DockStyle.Bottom;

            btnThucHien.Click += BtnThucHien_Click;
            Load += (s, e) =>
            {
                cboMaSV.DataSource = _svBus.GetAll();
                cboMaSV.DisplayMember = "HoTen";
                cboMaSV.ValueMember = "MaSV";
                cboMaHP.DataSource = _hpBus.GetAll();
                cboMaHP.DisplayMember = "TenHP";
                cboMaHP.ValueMember = "MaHP";
            };
        }

        private void BtnThucHien_Click(object sender, EventArgs e)
        {
            try
            {
                string maSV = Convert.ToString(cboMaSV.SelectedValue);
                _svBus.AddEnrollmentAndUpdateAverage(maSV, Convert.ToString(cboMaHP.SelectedValue),
                    (int)numHocKy.Value, numDiem.Value);
                lblKetQua.Text = "Đã commit: thêm đăng ký + tính lại DiemTB trong cùng transaction.";
            }
            catch (Exception ex)
            {
                lblKetQua.Text = "Giao dịch thất bại, đã rollback.\n" + ex.Message;
            }
        }
    }
}
