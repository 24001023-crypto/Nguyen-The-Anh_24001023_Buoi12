using Microsoft.Data.SqlClient;
using System.Data;
using Lab_12.DAL;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 10: Hoàn thiện chức năng CSDL - CRUD Khoa, SinhVien, HocPhan, DangKy
    /// + master-detail + tìm kiếm trong solution 3 lớp.
    /// Dùng SqlDataAdapter + SqlCommandBuilder để sinh CRUD tự động.
    /// </summary>
    public class Bai10Form : Form
    {
        private readonly TabControl tabs = new() { Dock = DockStyle.Fill };

        public Bai10Form()
        {
            Text = "Bài 10: CRUD hoàn chỉnh Khoa / SinhVien / HocPhan / DangKy + tìm kiếm";
            Width = 1000; Height = 640; StartPosition = FormStartPosition.CenterScreen;

            tabs.TabPages.Add(MakeTab("Khoa", "SELECT MaKhoa, TenKhoa FROM Khoa", "TenKhoa"));
            tabs.TabPages.Add(MakeTab("SinhVien",
                "SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.MaKhoa, sv.DiemTB, sv.Email FROM SinhVien sv",
                "HoTen", khoaFilter: true));
            tabs.TabPages.Add(MakeTab("HocPhan", "SELECT MaHP, TenHP, SoTinChi FROM HocPhan", "TenHP"));
            tabs.TabPages.Add(MakeTab("DangKy",
                "SELECT MaSV, MaHP, NgayDangKy, HocKy, Diem FROM DangKy", "MaSV"));

            Controls.Add(tabs);
        }

        private TabPage MakeTab(string tableName, string selectSql, string searchColumn, bool khoaFilter = false)
        {
            var page = new TabPage(tableName);

            var dgv = Ui.MakeGrid(readOnly: false);
            dgv.Dock = DockStyle.Fill;

            var txtSearch = new TextBox { Width = 250 };
            var cboKhoa = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 220, Visible = khoaFilter };
            var btnSearch = new Button { Text = "Tìm", Width = 70 };
            var btnSave = new Button { Text = "Lưu thay đổi", Width = 110 };
            var btnDelete = new Button { Text = "Xóa dòng chọn", Width = 110 };
            var btnRefresh = new Button { Text = "Nạp lại", Width = 90 };

            var panelSearch = new Panel { Dock = DockStyle.Top, Height = 44, Padding = new Padding(8) };
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill };
            flow.Controls.Add(new Label { Text = "Tìm kiếm:", AutoSize = true, TextAlign = ContentAlignment.MiddleCenter });
            flow.Controls.Add(txtSearch);
            flow.Controls.Add(btnSearch);
            if (khoaFilter) flow.Controls.Add(cboKhoa);
            flow.Controls.Add(btnSave);
            flow.Controls.Add(btnDelete);
            flow.Controls.Add(btnRefresh);
            panelSearch.Controls.Add(flow);

            page.Controls.Add(dgv);
            page.Controls.Add(panelSearch);

            // State của tab
            SqlDataAdapter da = new SqlDataAdapter(selectSql + " ORDER BY 1", DbConnectionFactory.Create());
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataTable table = new DataTable();

            void LoadData(string search = null, string maKhoa = null)
            {
                table.Clear();
                // Với SinhVien: lọc theo khoa trước rồi filter tìm kiếm bằng DataView
                da.Fill(table);
                string filter = null;
                if (!string.IsNullOrWhiteSpace(search))
                {
                    string safe = search.Replace("'", "''");
                    filter = $"{searchColumn} LIKE '%{safe}%'";
                    if (tableName == "SinhVien") filter += $" OR MaSV LIKE '%{safe}%'";
                    if (tableName == "DangKy") filter += $" OR MaHP LIKE '%{safe}%'";
                }
                if (khoaFilter && !string.IsNullOrEmpty(maKhoa))
                    filter = filter == null ? $"MaKhoa = '{maKhoa}'" : $"{filter} AND MaKhoa = '{maKhoa}'";
                table.DefaultView.RowFilter = filter;
                dgv.DataSource = table.DefaultView;
            }

            btnSearch.Click += (s, e) => LoadData(txtSearch.Text, khoaFilter ? Convert.ToString(cboKhoa.SelectedValue) : null);
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) LoadData(txtSearch.Text, khoaFilter ? Convert.ToString(cboKhoa.SelectedValue) : null); };
            btnSave.Click += (s, e) =>
            {
                try
                {
                    table.DefaultView.RowFilter = null;   // cập nhật toàn bộ bảng
                    dgv.DataSource = table;
                    int n = da.Update(table);
                    dgv.DataSource = table.DefaultView;
                    MessageBox.Show($"Đã lưu {n} thay đổi vào bảng {tableName}.", "Thành công");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lưu thất bại.\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    table.RejectChanges();
                    LoadData(txtSearch.Text, khoaFilter ? Convert.ToString(cboKhoa.SelectedValue) : null);
                }
            };
            btnDelete.Click += (s, e) =>
            {
                if (dgv.CurrentRow != null && MessageBox.Show("Xóa dòng đang chọn?", "Xác nhận",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dgv.Rows.RemoveAt(dgv.CurrentRow.Index);
                    int n = da.Update(table);
                    MessageBox.Show($"Đã xóa {n} dòng.");
                }
            };
            btnRefresh.Click += (s, e) => LoadData(txtSearch.Text, khoaFilter ? Convert.ToString(cboKhoa.SelectedValue) : null);

            if (khoaFilter)
            {
                // Master-detail: chọn khoa để lọc danh sách sinh viên
                cboKhoa.SelectedIndexChanged += (s, e) => LoadData(txtSearch.Text, Convert.ToString(cboKhoa.SelectedValue));
                page.Enter += (s, e) =>
                {
                    if (cboKhoa.Items.Count == 0)
                    {
                        cboKhoa.DataSource = Db.Query("SELECT MaKhoa, TenKhoa FROM Khoa");
                        cboKhoa.DisplayMember = "TenKhoa";
                        cboKhoa.ValueMember = "MaKhoa";
                    }
                };
            }

            Load += (s, e) => LoadData();
            return page;
        }
    }
}
