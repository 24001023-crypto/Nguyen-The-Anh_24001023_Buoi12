using Lab_12.BUS;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 7: Xóa khoa an toàn - trong transaction, xóa/chuyển các dữ liệu liên quan
    /// theo chính sách đã chọn; không để dữ liệu mồ côi.
    /// </summary>
    public class Bai7Form : Form
    {
        private readonly KhoaBUS _khoaBus = new KhoaBUS();

        private readonly ComboBox cboKhoa = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly RadioButton rdoXoaHet = new() { Text = "Xóa toàn bộ dữ liệu liên quan (đăng ký, sinh viên, lịch sử)", AutoSize = true };
        private readonly RadioButton rdoChan = new() { Text = "Hủy nếu khoa còn sinh viên (BLOCK)", AutoSize = true, Checked = true };
        private readonly Button btnXoa = new() { Text = "Xóa khoa (Transaction)", Dock = DockStyle.Bottom, Height = 40 };
        private readonly Label lblKetQua = new() { Dock = DockStyle.Bottom, Height = 60, TextAlign = ContentAlignment.MiddleLeft };

        public Bai7Form()
        {
            Text = "Bài 7: Xóa khoa an toàn (không để dữ liệu mồ côi)";
            Width = 680; Height = 340; StartPosition = FormStartPosition.CenterScreen;

            var table = Ui.MakeInputTable(1);
            Ui.AddRow(table, "Khoa cần xóa:", cboKhoa);

            var grp = new GroupBox { Text = "Chính sách xử lý dữ liệu liên quan", Dock = DockStyle.Top, Height = 70 };
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown };
            flow.Controls.Add(rdoXoaHet);
            flow.Controls.Add(rdoChan);
            grp.Controls.Add(flow);

            Controls.Add(btnXoa);
            Controls.Add(lblKetQua);
            Controls.Add(grp);
            Controls.Add(table);

            btnXoa.Click += BtnXoa_Click;
            Load += (s, e) =>
            {
                cboKhoa.DataSource = _khoaBus.GetAll();
                cboKhoa.DisplayMember = "TenKhoa";
                cboKhoa.ValueMember = "MaKhoa";
            };
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            string maKhoa = Convert.ToString(cboKhoa.SelectedValue);
            string policy = rdoXoaHet.Checked ? "DELETE_ALL" : "BLOCK";

            if (MessageBox.Show($"Xóa khoa {maKhoa} theo chính sách {policy}?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                var r = _khoaBus.DeleteDepartment(maKhoa, policy);
                lblKetQua.Text = $"Đã xóa khoa {maKhoa} (commit):\n" +
                                 $"- Đăng ký đã xóa: {r.SoDangKyDaXoa}\n" +
                                 $"- Lịch sử chuyển khoa đã xóa: {r.SoLichSuDaXoa}\n" +
                                 $"- Sinh viên đã xóa: {r.SoSinhVienDaXoa}";
                cboKhoa.DataSource = _khoaBus.GetAll(); // nạp lại danh sách
                cboKhoa.DisplayMember = "TenKhoa";
                cboKhoa.ValueMember = "MaKhoa";
            }
            catch (Exception ex)
            {
                lblKetQua.Text = "Không xóa được (rollback).\n" + ex.Message;
            }
        }
    }
}
