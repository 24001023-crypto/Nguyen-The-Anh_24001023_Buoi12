using Lab_12.BUS;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 6: Chuyển sinh viên sang khoa khác - transaction cập nhật MaKhoa
    /// và ghi lịch sử vào bảng LichSuChuyenKhoa.
    /// </summary>
    public class Bai6Form : Form
    {
        private readonly KhoaBUS _khoaBus = new KhoaBUS();

        private readonly ComboBox cboSinhVien = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly ComboBox cboKhoaMoi = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly TextBox txtGhiChu = new();
        private readonly Button btnChuyen = new() { Text = "Chuyển khoa", Dock = DockStyle.Bottom, Height = 40 };
        private readonly Label lblKetQua = new() { Dock = DockStyle.Bottom, Height = 40, TextAlign = ContentAlignment.MiddleLeft };

        public Bai6Form()
        {
            Text = "Bài 6: Chuyển sinh viên sang khoa khác (+ lịch sử chuyển khoa)";
            Width = 620; Height = 300; StartPosition = FormStartPosition.CenterScreen;

            var table = Ui.MakeInputTable(3);
            Ui.AddRow(table, "Sinh viên:", cboSinhVien);
            Ui.AddRow(table, "Khoa mới:", cboKhoaMoi);
            Ui.AddRow(table, "Ghi chú:", txtGhiChu);

            Controls.Add(btnChuyen);
            Controls.Add(lblKetQua);
            Controls.Add(table);

            btnChuyen.Click += BtnChuyen_Click;
            Load += (s, e) =>
            {
                cboSinhVien.DataSource = _khoaBus.GetAllSinhVien();
                cboSinhVien.DisplayMember = "HoTen";
                cboSinhVien.ValueMember = "MaSV";
                cboKhoaMoi.DataSource = _khoaBus.GetAll();
                cboKhoaMoi.DisplayMember = "TenKhoa";
                cboKhoaMoi.ValueMember = "MaKhoa";
            };
        }

        private void BtnChuyen_Click(object sender, EventArgs e)
        {
            try
            {
                string maSV = Convert.ToString(cboSinhVien.SelectedValue);
                string maKhoaMoi = Convert.ToString(cboKhoaMoi.SelectedValue);
                _khoaBus.TransferDepartment(maSV, maKhoaMoi, txtGhiChu.Text.Trim());
                lblKetQua.Text = $"Đã chuyển {maSV} sang khoa {maKhoaMoi} và ghi lịch sử (commit).";
            }
            catch (Exception ex)
            {
                lblKetQua.Text = "Thất bại, đã rollback.\n" + ex.Message;
            }
        }
    }
}
