using System.Data;
using Lab_12.BUS;
using Lab_12.DTO;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 8: Cập nhật điểm hàng loạt - nếu MỘT điểm ngoài [0,10] thì rollback toàn bộ.
    /// Sửa trực tiếp cột Diem trong lưới rồi bấm "Cập nhật hàng loạt".
    /// </summary>
    public class Bai8Form : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly DangKyBUS _dkBus = new DangKyBUS();

        private readonly ComboBox cboSinhVien = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly DataGridView dgv = Ui.MakeGrid(readOnly: false);
        private readonly Button btnCapNhat = new() { Text = "Cập nhật hàng loạt (Transaction)", Dock = DockStyle.Bottom, Height = 40 };
        private readonly Label lblKetQua = new() { Dock = DockStyle.Bottom, Height = 40, TextAlign = ContentAlignment.MiddleLeft };

        public Bai8Form()
        {
            Text = "Bài 8: Cập nhật điểm hàng loạt (điểm ngoài [0,10] -> rollback toàn bộ)";
            Width = 850; Height = 560; StartPosition = FormStartPosition.CenterScreen;

            var panelTop = new Panel { Dock = DockStyle.Top, Height = 44, Padding = new Padding(8) };
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill };
            flow.Controls.Add(new Label { Text = "Sinh viên:", AutoSize = true, TextAlign = ContentAlignment.MiddleCenter });
            cboSinhVien.Width = 260;
            flow.Controls.Add(cboSinhVien);
            panelTop.Controls.Add(flow);

            dgv.Dock = DockStyle.Fill;

            Controls.Add(dgv);
            Controls.Add(btnCapNhat);
            Controls.Add(lblKetQua);
            Controls.Add(panelTop);

            cboSinhVien.SelectedIndexChanged += (s, e) => LoadDangKy();
            btnCapNhat.Click += BtnCapNhat_Click;
            Load += (s, e) =>
            {
                cboSinhVien.DataSource = _svBus.GetAll();
                cboSinhVien.DisplayMember = "HoTen";
                cboSinhVien.ValueMember = "MaSV";
            };
        }

        private void LoadDangKy()
        {
            if (cboSinhVien.SelectedValue == null) return;
            dgv.Columns.Clear();
            var dt = _dkBus.GetByStudent(Convert.ToString(cboSinhVien.SelectedValue));
            dgv.DataSource = dt;
            foreach (DataGridViewColumn col in dgv.Columns)
                col.ReadOnly = col.Name != "Diem"; // chỉ cho sửa cột Diem
        }

        private void BtnCapNhat_Click(object sender, EventArgs e)
        {
            if (dgv.DataSource is not DataTable dt) return;

            // Đọc toàn bộ đăng ký trong lưới thành danh sách DTO
            var danhSach = new List<DangKyDTO>();
            foreach (DataRow row in dt.Rows)
            {
                var dk = new DangKyDTO
                {
                    MaSV = Convert.ToString(row["MaSV"]),
                    MaHP = Convert.ToString(row["MaHP"]),
                    HocKy = Convert.ToInt32(row["HocKy"]),
                    Diem = row["Diem"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(row["Diem"])
                };
                danhSach.Add(dk);
            }

            try
            {
                int rows = _svBus.UpdateGradesBulk(danhSach);
                lblKetQua.Text = $"Đã cập nhật {rows} đăng ký (commit).";
            }
            catch (Exception ex)
            {
                lblKetQua.Text = "Có điểm không hợp lệ -> ROLLBACK TOÀN BỘ, không dòng nào được lưu.\n" + ex.Message;
                LoadDangKy(); // nạp lại giá trị cũ từ CSDL
            }
        }
    }
}
