using System.Data;
using Lab_12.BUS;
using Lab_12.DTO;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 9: Kiểm soát xung đột cập nhật bằng cột RowVersion (timestamp).
    /// UPDATE ... WHERE MaSV = @MaSV AND RowVersion = @RowVersion.
    /// Nếu bản ghi đã bị người khác sửa -> ảnh hưởng 0 dòng -> phát hiện xung đột.
    /// </summary>
    public class Bai9Form : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();

        private readonly ComboBox cboSinhVien = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly TextBox txtHoTen = new();
        private readonly NumericUpDown numDiemTB = new() { Minimum = 0, Maximum = 10, DecimalPlaces = 2 };
        private readonly Button btnLuu = new() { Text = "Lưu (kiểm tra RowVersion)" };
        private readonly Button btnGiaLap = new() { Text = "Giả lập người khác sửa" };
        private readonly Label lblKetQua = new() { Dock = DockStyle.Bottom, Height = 60, TextAlign = ContentAlignment.MiddleLeft };

        private byte[] _rowVersion;

        public Bai9Form()
        {
            Text = "Bài 9: Kiểm soát xung đột cập nhật (RowVersion)";
            Width = 640; Height = 360; StartPosition = FormStartPosition.CenterScreen;

            var table = Ui.MakeInputTable(3);
            Ui.AddRow(table, "Sinh viên:", cboSinhVien);
            Ui.AddRow(table, "Họ tên:", txtHoTen);
            Ui.AddRow(table, "Điểm TB:", numDiemTB);

            var panelBtn = new Panel { Dock = DockStyle.Bottom, Height = 44, Padding = new Padding(8) };
            var flow = new FlowLayoutPanel { Dock = DockStyle.Fill };
            flow.Controls.Add(btnLuu);
            flow.Controls.Add(btnGiaLap);
            panelBtn.Controls.Add(flow);

            Controls.Add(panelBtn);
            Controls.Add(lblKetQua);
            Controls.Add(table);

            btnLuu.Click += BtnLuu_Click;
            btnGiaLap.Click += BtnGiaLap_Click;
            cboSinhVien.SelectedIndexChanged += (s, e) => LoadRecord();
            Load += (s, e) =>
            {
                cboSinhVien.DataSource = _svBus.GetAll();
                cboSinhVien.DisplayMember = "HoTen";
                cboSinhVien.ValueMember = "MaSV";
            };
        }

        private void LoadRecord()
        {
            if (cboSinhVien.SelectedValue == null) return;
            DataTable dt = _svBus.GetWithRowVersion(Convert.ToString(cboSinhVien.SelectedValue));
            if (dt.Rows.Count == 0) return;

            DataRow row = dt.Rows[0];
            txtHoTen.Text = Convert.ToString(row["HoTen"]);
            numDiemTB.Value = Convert.ToDecimal(row["DiemTB"]);
            _rowVersion = (byte[])row["RowVersion"];
            lblKetQua.Text = "Đã tải bản ghi (RowVersion: " + Convert.ToBase64String(_rowVersion) + ")";
        }

        private void BtnLuu_Click(object sender, EventArgs e)
        {
            if (_rowVersion == null) return;
            var dto = new SinhVienDTO
            {
                MaSV = Convert.ToString(cboSinhVien.SelectedValue),
                HoTen = txtHoTen.Text.Trim(),
                DiemTB = numDiemTB.Value
            };
            int rows = _svBus.UpdateWithConcurrency(dto, _rowVersion);
            if (rows == 0)
            {
                lblKetQua.Text = "XUNG ĐỘT! Bản ghi đã bị người khác sửa (RowVersion khác). " +
                                 "Dữ liệu KHÔNG được lưu. Hãy nạp lại rồi sửa tiếp.";
                LoadRecord();
            }
            else
            {
                lblKetQua.Text = "Lưu thành công (RowVersion khớp).";
                LoadRecord();
            }
        }

        private void BtnGiaLap_Click(object sender, EventArgs e)
        {
            string maSV = Convert.ToString(cboSinhVien.SelectedValue);
            // Người khác sửa trực tiếp CSDL, không qua RowVersion của ta
            _svBus.SimulateExternalUpdate(maSV, txtHoTen.Text + " (đã sửa bởi người khác)", 5.5m);
            lblKetQua.Text = "Đã giả lập: người khác vừa sửa bản ghi này trong CSDL.\n" +
                             "Bây giờ bấm 'Lưu' để thấy cơ chế phát hiện xung đột.";
        }
    }
}
