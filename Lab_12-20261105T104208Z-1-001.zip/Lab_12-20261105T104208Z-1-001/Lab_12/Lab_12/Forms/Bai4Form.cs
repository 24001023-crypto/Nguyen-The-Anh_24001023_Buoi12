using System.Data;
using Lab_12.BUS;
using Lab_12.DTO;

namespace Lab_12.Forms
{
    /// <summary>
    /// Bài 4: Mô phỏng lỗi và kiểm chứng Rollback.
    /// Cố ý thêm một mã học phần KHÔNG tồn tại (HP999) ở bước 2 -> FK violation
    /// -> transaction rollback -> sinh viên cũng không được lưu.
    /// Số bản ghi trước/sau được ghi lại để kiểm chứng.
    /// </summary>
    public class Bai4Form : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly KhoaBUS _khoaBus = new KhoaBUS();
        private readonly HocPhanBUS _hpBus = new HocPhanBUS();

        private readonly TextBox txtMaSV = new() { Text = "SV099" };
        private readonly TextBox txtHoTen = new() { Text = "Nguyễn Văn Thử Lỗi" };
        private readonly ComboBox cboMaKhoa = new() { DropDownStyle = ComboBoxStyle.DropDownList };
        private readonly CheckedListBox lstHocPhan = new() { CheckOnClick = true };
        private readonly Button btnChayLoi = new() { Text = "Chạy giao dịch CÓ mã HP sai", Height = 40, Dock = DockStyle.Top };
        private readonly Button btnChayDung = new() { Text = "Chạy giao dịch hợp lệ (so sánh)", Height = 40, Dock = DockStyle.Top };
        private readonly Label lblKetQua = new()
        {
            Dock = DockStyle.Fill,
            Text = "Sẵn sàng.",
            TextAlign = ContentAlignment.TopLeft,
            Padding = new Padding(8)
        };

        public Bai4Form()
        {
            Text = "Bài 4: Mô phỏng lỗi và kiểm chứng Rollback";
            Width = 700; Height = 560; StartPosition = FormStartPosition.CenterScreen;

            var table = Ui.MakeInputTable(3);
            Ui.AddRow(table, "Mã SV:", txtMaSV);
            Ui.AddRow(table, "Họ tên:", txtHoTen);
            Ui.AddRow(table, "Khoa:", cboMaKhoa);
            var panelTop = new Panel { Dock = DockStyle.Top, Height = 110 };
            panelTop.Controls.Add(table);

            var panelBottom = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };
            var lbl = new Label { Text = "Học phần đăng ký (một mã HP999 KHÔNG tồn tại sẽ được cố ý thêm vào):", Dock = DockStyle.Top, Height = 26 };
            panelBottom.Controls.Add(lstHocPhan);
            panelBottom.Controls.Add(lbl);

            Controls.Add(lblKetQua);
            Controls.Add(panelBottom);
            Controls.Add(btnChayLoi);
            Controls.Add(btnChayDung);
            Controls.Add(panelTop);

            btnChayLoi.Click += (s, e) => ChayThu(coLoi: true);
            btnChayDung.Click += (s, e) => ChayThu(coLoi: false);

            Load += (s, e) =>
            {
                cboMaKhoa.DataSource = _khoaBus.GetAll();
                cboMaKhoa.DisplayMember = "TenKhoa";
                cboMaKhoa.ValueMember = "MaKhoa";
                lstHocPhan.DataSource = _hpBus.GetAll();
                lstHocPhan.DisplayMember = "TenHP";
                // tick sẵn 2 học phần đầu
                lstHocPhan.SetItemChecked(0, true);
                if (lstHocPhan.Items.Count > 1) lstHocPhan.SetItemChecked(1, true);
            };
        }

        private void ChayThu(bool coLoi)
        {
            string maSV = txtMaSV.Text.Trim();
            if (string.IsNullOrEmpty(maSV)) { MessageBox.Show("Nhập mã SV."); return; }

            int truoc = _svBus.CountAll();

            var sv = new SinhVienDTO
            {
                MaSV = maSV,
                HoTen = txtHoTen.Text.Trim(),
                NgaySinh = new DateTime(2005, 6, 1),
                GioiTinh = true,
                MaKhoa = Convert.ToString(cboMaKhoa.SelectedValue),
                DiemTB = 0
            };

            var ds = new List<DangKyDTO>();
            foreach (var item in lstHocPhan.CheckedItems)
            {
                var row = ((DataRowView)item).Row;
                ds.Add(new DangKyDTO { MaHP = Convert.ToString(row["MaHP"]), HocKy = 1, Diem = null });
            }
            if (coLoi)
                ds.Add(new DangKyDTO { MaHP = "HP999", HocKy = 1, Diem = null }); // mã KHÔNG tồn tại!

            try
            {
                _svBus.AddStudentWithEnrollments(sv, ds);
                int sau = _svBus.CountAll();
                lblKetQua.Text = $"[Hợp lệ] Commit OK.\nTrước: {truoc} sinh viên | Sau: {sau} sinh viên.\n" +
                                 $"Kiểm chứng: EXISTS({maSV}) = {_svBus.Exists(maSV)}";
            }
            catch (Exception ex)
            {
                int sau = _svBus.CountAll();
                lblKetQua.Text = $"[Có lỗi] Giao dịch thất bại và đã hoàn tác (rollback).\n{ex.Message}\n\n" +
                                 $"Kiểm chứng Rollback:\n" +
                                 $"- Trước: {truoc} sinh viên | Sau: {sau} sinh viên (không đổi).\n" +
                                 $"- EXISTS({maSV}) = {_svBus.Exists(maSV)} -> KHÔNG có dữ liệu dở dang.";
            }
        }
    }
}
