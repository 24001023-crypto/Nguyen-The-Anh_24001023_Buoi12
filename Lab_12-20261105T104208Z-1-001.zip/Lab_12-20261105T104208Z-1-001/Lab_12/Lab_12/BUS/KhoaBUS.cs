using Microsoft.Data.SqlClient;
using System.Data;
using Lab_12.DAL;

namespace Lab_12.BUS
{
    /// <summary>Kết quả xóa khoa an toàn (Bài 7) để hiển thị số liệu.</summary>
    public class DeleteDepartmentResult
    {
        public int SoDangKyDaXoa;
        public int SoSinhVienDaXoa;
        public int SoLichSuDaXoa;
    }

    public class KhoaBUS
    {
        private readonly KhoaDAL _khoaDal = new();
        private readonly SinhVienDAL _svDal = new();
        private readonly DangKyDAL _dkDal = new();
        private readonly LichSuChuyenKhoaDAL _lsDal = new();

        public DataTable GetAll()
        {
            return _khoaDal.GetAll();
        }

        public DataTable GetAllSinhVien(string search = null)
        {
            return _svDal.GetAll(search);
        }

        public int CountSinhVien(string maKhoa)
        {
            return _svDal.CountByDepartment(maKhoa);
        }

        /// <summary>
        /// Bài 6: chuyển sinh viên sang khoa khác + ghi lịch sử trong MỘT transaction.
        /// </summary>
        public void TransferDepartment(string maSV, string maKhoaMoi, string ghiChu)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                if (!_svDal.Exists(maSV, conn, tx))
                    throw new Exception("Sinh viên không tồn tại: " + maSV);
                if (!_khoaDal.Exists(maKhoaMoi, conn, tx))
                    throw new Exception("Khoa đích không tồn tại: " + maKhoaMoi);

                string maKhoaCu = Convert.ToString(Db.Scalar(conn, tx,
                    "SELECT MaKhoa FROM SinhVien WHERE MaSV = @MaSV",
                    new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV }));

                if (maKhoaCu == maKhoaMoi)
                    throw new Exception("Sinh viên đã thuộc khoa này rồi.");

                _svDal.UpdateMaKhoa(maSV, maKhoaMoi, conn, tx);
                _lsDal.Insert(maSV, maKhoaCu, maKhoaMoi, ghiChu, conn, tx);

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>
        /// Bài 7: xóa khoa an toàn trong transaction.
        /// policy = "DELETE_ALL": xóa DangKy -> SinhVien -> LichSuChuyenKhoa -> Khoa.
        /// policy = "BLOCK": hủy nếu khoa còn sinh viên (không để dữ liệu mồ côi).
        /// </summary>
        public DeleteDepartmentResult DeleteDepartment(string maKhoa, string policy)
        {
            var result = new DeleteDepartmentResult();
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                if (!_khoaDal.Exists(maKhoa, conn, tx))
                    throw new Exception("Khoa không tồn tại: " + maKhoa);

                if (policy == "BLOCK" && _svDal.CountByDepartment(maKhoa, conn, tx) > 0)
                    throw new Exception("Khoa còn sinh viên, không cho phép xóa (chính sách BLOCK).");

                // 1. Xóa đăng ký của các sinh viên thuộc khoa
                result.SoDangKyDaXoa = _dkDal.CountByDepartment(maKhoa, conn, tx);
                Db.Exec(conn, tx, @"DELETE dk FROM DangKy dk
                                    JOIN SinhVien sv ON dk.MaSV = sv.MaSV
                                    WHERE sv.MaKhoa = @MaKhoa",
                    new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa });

                // 2. Xóa lịch sử chuyển khoa liên quan
                result.SoLichSuDaXoa = _lsDal.DeleteByDepartment(maKhoa, conn, tx);

                // 3. Xóa sinh viên
                result.SoSinhVienDaXoa = _svDal.CountByDepartment(maKhoa, conn, tx);
                Db.Exec(conn, tx, "DELETE FROM SinhVien WHERE MaKhoa = @MaKhoa",
                    new SqlParameter("@MaKhoa", SqlDbType.VarChar, 10) { Value = maKhoa });

                // 4. Xóa khoa
                _khoaDal.Delete(maKhoa, conn, tx);

                tx.Commit();
                return result;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }
    }
}
