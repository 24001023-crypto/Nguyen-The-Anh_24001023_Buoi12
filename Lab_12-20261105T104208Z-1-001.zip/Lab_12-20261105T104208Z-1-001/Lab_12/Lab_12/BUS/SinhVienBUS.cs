using Microsoft.Data.SqlClient;
using System.Data;
using Lab_12.DAL;
using Lab_12.DTO;

namespace Lab_12.BUS
{
    public class SinhVienBUS
    {
        private readonly SinhVienDAL _sinhVienDal = new();
        private readonly DangKyDAL _dangKyDal = new();

        /// <summary>Bài 1: dùng cho lưới chi tiết.</summary>
        public DataTable GetByDepartment(string maKhoa)
        {
            return _sinhVienDal.GetByDepartment(maKhoa);
        }

        public DataTable GetAll(string search = null)
        {
            return _sinhVienDal.GetAll(search);
        }

        public bool Exists(string maSV)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            return _sinhVienDal.Exists(maSV, conn, null);
        }

        public int CountAll()
        {
            return _sinhVienDal.CountAll();
        }

        public DataTable GetWithRowVersion(string maSV)
        {
            return _sinhVienDal.GetWithRowVersion(maSV);
        }

        /// <summary>
        /// Bài 3 + 4: trong MỘT giao dịch, thêm sinh viên rồi thêm danh sách
        /// đăng ký học phần ban đầu. Lỗi ở bất kỳ bước nào -> Rollback toàn bộ.
        /// </summary>
        public void AddStudentWithEnrollments(SinhVienDTO sv, List<DangKyDTO> danhSachDangKy)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            SqlTransaction tx = conn.BeginTransaction();
            try
            {
                if (_sinhVienDal.Exists(sv.MaSV, conn, tx))
                    throw new Exception("Mã sinh viên đã tồn tại: " + sv.MaSV);

                // Bước 1: thêm sinh viên
                const string sqlInsertSinhVien = @"INSERT INTO SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email)
                                                   VALUES(@MaSV, @HoTen, @NgaySinh, @GioiTinh, @MaKhoa, @DiemTB, @Email)";
                using (SqlCommand cmdSv = new SqlCommand(sqlInsertSinhVien, conn, tx))
                {
                    cmdSv.Parameters.Add("@MaSV", SqlDbType.VarChar, 15).Value = sv.MaSV;
                    cmdSv.Parameters.Add("@HoTen", SqlDbType.NVarChar, 100).Value = sv.HoTen;
                    cmdSv.Parameters.Add("@NgaySinh", SqlDbType.Date).Value = sv.NgaySinh;
                    cmdSv.Parameters.Add("@GioiTinh", SqlDbType.Bit).Value = sv.GioiTinh;
                    cmdSv.Parameters.Add("@MaKhoa", SqlDbType.VarChar, 10).Value = sv.MaKhoa;
                    cmdSv.Parameters.Add("@DiemTB", SqlDbType.Decimal).Value = sv.DiemTB;
                    cmdSv.Parameters.Add("@Email", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(sv.Email) ? (object)DBNull.Value : sv.Email;
                    cmdSv.ExecuteNonQuery();
                }

                // Bước 2: thêm các đăng ký (mã HP sai sẽ vi phạm FK ở đây)
                foreach (DangKyDTO dk in danhSachDangKy)
                {
                    using (SqlCommand cmdDk = new SqlCommand(
                        @"INSERT INTO DangKy(MaSV, MaHP, HocKy, Diem) VALUES(@MaSV, @MaHP, @HocKy, @Diem)", conn, tx))
                    {
                        cmdDk.Parameters.Add("@MaSV", SqlDbType.VarChar, 15).Value = sv.MaSV;
                        cmdDk.Parameters.Add("@MaHP", SqlDbType.VarChar, 10).Value = dk.MaHP;
                        cmdDk.Parameters.Add("@HocKy", SqlDbType.Int).Value = dk.HocKy;
                        cmdDk.Parameters.Add("@Diem", SqlDbType.Decimal).Value =
                            dk.Diem.HasValue ? (object)dk.Diem.Value : DBNull.Value;
                        cmdDk.ExecuteNonQuery();
                    }
                }

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>
        /// Bài 5: BUS điều phối - gọi DAL với Connection/Transaction truyền từ ngoài,
        /// vừa thêm đăng ký vừa tính lại DiemTB trong cùng giao dịch.
        /// </summary>
        public void AddEnrollmentAndUpdateAverage(string maSV, string maHP, int hocKy, decimal? diem)
        {
            using var conn = DbConnectionFactory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                var dto = new DangKyDTO { MaSV = maSV, MaHP = maHP, HocKy = hocKy, Diem = diem };
                _dangKyDal.InsertEnrollment(dto, conn, tx);

                Db.Exec(conn, tx, @"UPDATE SinhVien
                                    SET DiemTB = ISNULL((SELECT AVG(Diem) FROM DangKy
                                                         WHERE MaSV = @MaSV AND Diem IS NOT NULL), 0)
                                    WHERE MaSV = @MaSV",
                    new SqlParameter("@MaSV", SqlDbType.VarChar, 15) { Value = maSV });

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Bài 8: cập nhật điểm hàng loạt; có điểm ngoài [0,10] -> rollback toàn bộ.</summary>
        public int UpdateGradesBulk(List<DangKyDTO> danhSach)
        {
            // Kiểm tra dữ liệu trước khi mở transaction
            foreach (var dk in danhSach)
            {
                if (!dk.Diem.HasValue)
                    throw new Exception($"Đăng ký {dk.MaSV}-{dk.MaHP} chưa có điểm.");
                if (dk.Diem.Value < 0 || dk.Diem.Value > 10)
                    throw new Exception($"Điểm của {dk.MaSV}-{dk.MaHP} = {dk.Diem} nằm ngoài khoảng [0,10]!");
            }

            using var conn = DbConnectionFactory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                int rows = 0;
                foreach (var dk in danhSach)
                    rows += _dangKyDal.UpdateDiem(dk.MaSV, dk.MaHP, dk.Diem.Value, conn, tx);
                tx.Commit();
                return rows;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Bài 9: lưu có kiểm tra RowVersion. Trả về số dòng cập nhật được (0 = xung đột).</summary>
        public int UpdateWithConcurrency(SinhVienDTO dto, byte[] rowVersion)
        {
            return _sinhVienDal.UpdateWithRowVersion(dto, rowVersion);
        }

        /// <summary>Bài 9: giả lập người khác đã sửa bản ghi trước.</summary>
        public int SimulateExternalUpdate(string maSV, string hoTen, decimal diemTB)
        {
            return _sinhVienDal.UpdateIgnoreRowVersion(maSV, hoTen, diemTB);
        }
    }
}
