using System.Data;
using Lab_12.DAL;
using Lab_12.DTO;

namespace Lab_12.BUS
{
    public class DangKyBUS
    {
        private readonly DangKyDAL _dangKyDal = new();

        public DataTable GetByStudent(string maSV)
        {
            return _dangKyDal.GetByStudent(maSV);
        }

        public DataTable GetAllWithNames(string search = null)
        {
            return _dangKyDal.GetAllWithNames(search);
        }

        public void Add(DangKyDTO dto)
        {
            _dangKyDal.InsertEnrollment(dto, null, null);
        }
    }

    public class HocPhanBUS
    {
        private readonly HocPhanDAL _hocPhanDal = new();

        public DataTable GetAll()
        {
            return _hocPhanDal.GetAll();
        }
    }
}
