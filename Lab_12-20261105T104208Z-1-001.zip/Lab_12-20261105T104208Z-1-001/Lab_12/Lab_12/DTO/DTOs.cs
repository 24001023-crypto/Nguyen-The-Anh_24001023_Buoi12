namespace Lab_12.DTO
{
    public class KhoaDTO
    {
        public string MaKhoa { get; set; }
        public string TenKhoa { get; set; }
    }

    public class SinhVienDTO
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public bool GioiTinh { get; set; }          // 1: Nam, 0: Nữ
        public string MaKhoa { get; set; }
        public decimal DiemTB { get; set; }
        public string Email { get; set; }
        public byte[] RowVersion { get; set; }      // dùng cho Bài 9 (kiểm soát xung đột)
    }

    public class HocPhanDTO
    {
        public string MaHP { get; set; }
        public string TenHP { get; set; }
        public int SoTinChi { get; set; }
    }

    public class DangKyDTO
    {
        public string MaSV { get; set; }
        public string MaHP { get; set; }
        public int HocKy { get; set; }
        public decimal? Diem { get; set; }
    }
}
